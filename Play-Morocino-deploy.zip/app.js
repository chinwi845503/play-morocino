const menuToggle = document.querySelector("#menuToggle");
const mainNav = document.querySelector("#mainNav");

menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});
mainNav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  mainNav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));

document.querySelector("#year").textContent = new Date().getFullYear();

const filterButtons = document.querySelectorAll(".filter");
const productCards = document.querySelectorAll(".product-card");
filterButtons.forEach(button => {
  button.addEventListener("click", () => {
    filterButtons.forEach(item => item.classList.toggle("active", item === button));
    const filter = button.dataset.filter;
    productCards.forEach(card => {
      card.hidden = filter !== "all" && card.dataset.category !== filter;
    });
  });
});

const serviceSelect = document.querySelector("#serviceSelect");
document.querySelectorAll(".product-order").forEach(button => {
  button.addEventListener("click", () => {
    serviceSelect.value = button.dataset.product;
    document.querySelector("#contact").scrollIntoView({ behavior: "smooth" });
    document.querySelector("#customerName").focus({ preventScroll: true });
  });
});

const form = document.querySelector("#orderForm");
const result = document.querySelector("#formResult");
const messageEl = document.querySelector("#orderMessage");
let orderMessage = "";

form.addEventListener("submit", event => {
  event.preventDefault();
  const name = document.querySelector("#customerName").value.trim();
  const service = serviceSelect.value;
  const details = document.querySelector("#details").value.trim();
  const payment = document.querySelector("#paymentMethod").value;
  orderMessage = `سلام Play Morocino! بغيت نطلب/نستفسر على: ${service}\\nالاسم/اسم اللاعب: ${name}\\nطريقة الأداء المفضلة: ${payment}\\nالتفاصيل: ${details || "بغيت نعرف التفاصيل والحالة ديال الطلب."}\\nعافاكم أكدوا ليا الثمن والتفاصيل قبل أي أداء. للتواصل عبر واتساب: https://wa.me/212645448983.`;
  messageEl.textContent = orderMessage;
  result.hidden = false;
});

document.querySelector("#copyOrder").addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(orderMessage);
    document.querySelector("#copyOrder").textContent = "تنسخات الرسالة ✓";
  } catch {
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(messageEl);
    selection.removeAllRanges();
    selection.addRange(range);
    document.querySelector("#copyOrder").textContent = "حدد الرسالة ونسخها";
  }
});

document.querySelector("#shareOrder").addEventListener("click", async () => {
  if (navigator.share) {
    try { await navigator.share({ title: "طلب من Play Morocino", text: orderMessage }); }
    catch (error) { if (error.name !== "AbortError") alert("يمكنك نسخ الرسالة ومشاركتها يدوياً."); }
  } else {
    try {
      await navigator.clipboard.writeText(orderMessage);
      alert("تنسخات الرسالة. لصقها فالتطبيق اللي بغيتي.");
    } catch {
      alert("حدد الرسالة وانسخها يدوياً.");
    }
  }
});
